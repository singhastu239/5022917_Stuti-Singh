package springfox.documentation.builders;

public class PathSelectors {

	public static Object any() {
		// TODO Auto-generated method stub
		return null;
	}

}
